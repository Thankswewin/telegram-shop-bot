from wrapper import ChatGPT

print(ChatGPT().ask_question("Test"))